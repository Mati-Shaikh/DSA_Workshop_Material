//M Mati Ur Rehman
//CS-A
//i21-1222
#pragma once
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
class K_mean_algo {
public:
    // Function to calculate Euclidean distance
	double euclidean_distance(double x1, double y1, double x2, double y2) {
		return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	}       //Function ends

    //Void Function whihc reads the file storing into 2D array and Performing K mean Algorithm to Form Clusters
	void k_Mean_clustering()
	{
        //Data types and fstream opertaions to open and read the file
        string line;
        ifstream file("driver-data.csv");
        srand(time(0));         //srand function to generate random numbers on the screen

        ifstream file1("driver-data.csv");
        while (getline(file1, line))
        {
            cout << line << endl;
        }
        file1.close();
      
        /// /Initializing cell and cell_1 chracter arrays to store data from the filw
        int j = 0;
        char* cell = new char[30];
        char* cell_1 = new char[30];
        double** array = new double* [4000];        //Initalizination of Dynamic Double Array to store the data in it
        for (int i = 0; i < 4000; i++)
        {
            array[i] = new double[2];
        }

        //Initalization of some variables to store characters in an character array
        int i = 0;
        bool f = false;
        int k = 0;

        int count = 0;

        //Using whle and getline to store Float vaues in cell character array
        while (getline(file, line))
        {

            //using bool to ignore the very first line
            if (f == true)
            {
                //Using while to Ignore 1st column of the csv file 
                while (line[i] != ',')
                {
                    i++;
                }
                i++;
                //using another while to store data of 2nd column in the character array cell name
                while (line[i] != ',')
                {
                    cell[j] = line[i];
                    j++;
                    i++;
                }
                i++;
                //using another while to store data of 3rd column in the character array cell_1 name
                while (line[i] != '\0')
                {

                    cell_1[k] = line[i];
                    k++;
                    i++;
                }
                cell_1[k] = '\0';
                cell[j] = '\0';

                j = 0;
                k = 0;
                //cout << cell << endl;
                //cout << cell_1 << endl;

                //Conversion of string/character array into a double variable
                double cont_to_double = stod(cell);
                double cont_to_int = stod(cell_1);




                //Now storing values in 2D arrays

                array[count][0] = cont_to_double;//cont_to_int;
                array[count][1] = cont_to_int;

                count++;
                //Printing values
            }
            f = true;
            i = 0;
        }//While ends


        for (int i = 0; i < 4000; i++)
        {
            cout <<"Mean Distance : " << array[i][0] << " " <<"Mean Speed : " << array[i][1] << endl;
        }


       //Now Applying K Clustering Mean Algorithm
        const int K = 4;    // number of clusters
        double centroids[K][2];  // 2D array to store centroids
        int clusters[4000];  // array to store the cluster each data point belongs to

        // initialize centroids randomly
        for (int i = 0; i < K; i++) {
            int randomIndex = rand() % 4000;  // select a random data point as centroid
            centroids[i][0] = array[randomIndex][0];
            centroids[i][1] = array[randomIndex][1];
        }
        //this Prearray checking the condition of untill centriods
        int prearr[3][2];
        // Repeat the following steps until the centroids no longer change
        do
        {           
            //Using for loop to store centriods in an array
            for (int i = 0; i < 3; i++)
            {
                prearr[i][0] = centroids[i][0];
                prearr[i][1] = centroids[i][1];
            }

            // assign each data point to the closest centroid
            for (int i = 0; i < 4000; i++) 
            {
                //Thsi double variable compute the distance using euclidia distance formula
                double min_distance = euclidean_distance(array[i][0], array[i][1], centroids[0][0], centroids[0][1]);
                int min_cluster = 1;
                //Using For loop to compute the distance of upcoming clusters
                for (int j = 1; j < K; j++) {
                    double distance = euclidean_distance(array[i][0], array[i][1], centroids[j][0], centroids[j][1]);
                    if (distance < min_distance) {
                        min_distance = distance;
                        min_cluster = j;
                    }

                }
                //Storing values in clusters
                clusters[i] = min_cluster;
            }
            // recalculate the centroids
            for (int i = 0; i < K; i++) 
            {
                double sum_x = 0;
                double sum_y = 0;
                int count = 0;
                for (int j = 0; j < 4000; j++) {
                    if (clusters[j] == i) {
                        sum_x = sum_x + array[j][0];
                        sum_y = sum_y + array[j][1];
                        count++;
                    }
                }
                //Final computation of centroids
                centroids[i][0] = sum_x / count;
                centroids[i][1] = sum_y / count;
            }   //For loop ends of computing centroids
        } while (prearr[0][0] == centroids[0][0] && prearr[0][1] == centroids[0][1] && prearr[1][0] == centroids[1][0] && prearr[1][1] == centroids[1][1] && prearr[2][0] == centroids[2][0] && prearr[2][1] == centroids[2][1]);

        //
        cout << "\n\n\nClusters Computation Completed .........." << endl;
        for (int i = 0; i < 4000; i++)
        {
            cout << "Mean Distance : " << array[i][0] <<"\tMean Speed : " << array[i][1] <<"\tCluster Value : "<< clusters[i] << endl;
        }

        file.close();       //closing the file
        cout << "\n\nClustering After Applying K Mean Algorithm is Completed ." << endl;

        string word;            //This string word used to write clusters in the csv file
        //Again Opening the file and performing Operations to get Our Result
        fstream in;
        in.open("driver-data.csv", ios::in);
        fstream out;
        out.open("data_Q1.csv", ios::out | ios::app);
        int mov = 0;
        bool stop = true;
        //Using While to write Data Into The File
        while (in >> word)
        {
            if (stop)
            {
                word += ",";
                word += "Clusters";
                out << word << "\n";
                stop = false;
            }
            else
            {
                word += "," + to_string(clusters[mov]);
                out << word << "\n";
                mov++;
            }

        }
        cout << "\n\n\n\t\tClusters Are Successfully Written Into the File." << endl;
        in.close();
        //Operation are Successsfully Completed
	}
};