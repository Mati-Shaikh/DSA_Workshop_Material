import pandas as pd
import matplotlib.pyplot as plt

# Load CSV file into pandas dataframe
df = pd.read_csv('Question2_data.csv')

plt.style.use('bmh')
#df=pd.read_csv("output-Q1.csv")

colors=['red', 'blue', 'green', 'orange','yellow']
for i in range(4):
    x=df[df['Clusters']==i+1]['Annual Income (k$)']
    y=df[df['Clusters']==i+1]['Spending Score (1-100)']
    plt.scatter(x, y, c=colors[i],label='K'+str(i+1))
# Create a scatter plot using matplotlib
#plt.scatter(df['mean_dist_day'], df['mean_over_speed_perc'])
plt.title('Scatter Plot')
plt.xlabel('Annual Income (k$)')
plt.ylabel('Spending Score (1-100)')
plt.show()
