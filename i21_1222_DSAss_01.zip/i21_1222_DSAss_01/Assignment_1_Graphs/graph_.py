import pandas as pd
import matplotlib.pyplot as plt

# Load CSV file into pandas dataframe
df = pd.read_csv('data_Q1.csv')

plt.style.use('bmh')
#df=pd.read_csv("output-Q1.csv")

colors=['red', 'blue', 'green', 'orange','yellow']
for i in range(4):
    x=df[df['Clusters']==i+1]['mean_dist_day']
    y=df[df['Clusters']==i+1]['mean_over_speed_perc']
    plt.scatter(x, y, c=colors[i],label='K'+str(i+1))
# Create a scatter plot using matplotlib
#plt.scatter(df['mean_dist_day'], df['mean_over_speed_perc'])
plt.title('Scatter Plot')
plt.xlabel('mean_dist_day')
plt.ylabel('mean_over_speed_perc')
plt.show()
#right graph
