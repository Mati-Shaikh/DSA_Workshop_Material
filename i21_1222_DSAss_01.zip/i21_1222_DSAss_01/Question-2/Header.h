//M Mati Ur Rehman
//CS-A
//i21-1222

#pragma once
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
// Function to calculate Euclidean distance
double euclidean_distance(double x1, double y1, double z1, double x2, double y2, double z2) {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2));
}//Function ends
class K_mean_algo {
public:
    //Void Function whihc reads the file storing into 2D array and Performing K mean Algorithm to Form Clusters
    void k_Mean_clustering()
    {
        //Data types and fstream opertaions to open and read the file
        string line;
        srand(time(0));         //srand function to generate random numbers on the screen

        ifstream file_1("segmented_customers-1.csv");
        while (getline(file_1, line))
        {
            cout << line << endl;
        }
        file_1.close();


        //Opening the file and performing the operations
        ifstream file("segmented_customers-1.csv");
        int j = 0;
        char* cell = new char[30];
        char* cell_1 = new char[30];
        char* cell_2 = new char[30];
        int i = 0;
        int k = 0;
        int l = 0;
        bool f = false;
        int counter = 0;
        int** array = new int* [200];
        for (int i = 0; i < 200; i++)
        {
            array[i] = new int[4];
        }
        //Using whle and getline to store Float vaues in cell character array

            //Now storing the values in an array and output it on the screen
        cout << "/n/n/tAfter Storing Values in an Array" << endl;
        while (getline(file, line))
        {
            //cout << line<<endl;
            //cout << "\n\n\tReading the whole data from the file succesfully" << endl;
            //using bool to ignore the very first line
            if (f == true)
            {
                //ignoring 1st column
                while (line[i] != ',')
                {
                    i++;
                }
                i++;
                //ignoring second column
                while (line[i] != ',')
                {
                    i++;
                }
                i++;
                //storing values in the chracter cell array
                while (line[i] != ',')
                {
                    cell[j] = line[i];
                    j++;
                    i++;
                }
                i++;
                //storing values in the chracter cell_1 array
                while (line[i] != ',')
                {
                    cell_1[k] = line[i];
                    k++;
                    i++;
                }
                i++;

                //storing values in the chracter cell_2 array
                while (line[i] != '\0')
                {
                    cell_2[l] = line[i];
                    l++;
                    i++;
                }
                //Now ignoring \0 character from the whole array
                cell_2[l] = '\0';
                cell_1[k] = '\0';
                cell[j] = '\0';
                j = 0;
                k = 0;
                l = 0;
                //cout << cell;
                int cont_to_double = stoi(cell);
                int cont_to_int_1 = stoi(cell_1);
                int cont_to_int_2 = stoi(cell_2);
                //cout << "\n\n\tNow The exact Data in sequential Form: " << endl;
                cout << "Age : " << cont_to_double << endl;
                cout << "Annual Income : " << cont_to_int_1 << endl;
                cout << "Supporting Income : " << cont_to_int_2 << endl;


                //Now storing values in an array
                array[counter][0] = cont_to_double;
                array[counter][1] = cont_to_int_1;
                array[counter][2] = cont_to_int_2;
                counter++;
            }
            f = true;
            i = 0;
        }
        //Showing Output of a Storing Values in an Array
        for (int i = 0; i < 200; i++)
        {
            cout << array[i][0] << " " << array[i][1] << " " << array[i][2] << endl;
        }


        //Now Applying K Clustering Mean Algorithm
        const int K = 5;    // number of clusters
        double centroids[K][4];  // 2D array to store centroids
        int clusters[200];  // array to store the cluster each data point belongs to


        for (int i = 0; i < K; i++) {
            int randomIndex = rand() % 200;  // select a random data point as centroid
            centroids[i][0] = array[randomIndex][0];
            centroids[i][1] = array[randomIndex][1];
            centroids[i][2] = array[randomIndex][2];
        }
        //this Prearray checking the condition of untill centriods

        int prearr[3][3];

        // Repeat the following steps until the centroids no longer change
        //for (int iter = 0; iter < 200; iter++) {
        do {
            //Using for loop to store centriods in an array

            for (int i = 0; i < 3; i++)
            {
                prearr[i][0] = centroids[i][0];
                prearr[i][1] = centroids[i][1];
                prearr[i][2] = centroids[i][2];
            }

            // assign each data point to the closest centroid
            for (int i = 0; i < 200; i++) {
                //Thsi double variable compute the distance using euclidia distance formula

                double min_distance = euclidean_distance(array[i][0], array[i][1], array[i][2], centroids[0][0], centroids[0][1], centroids[0][2]);
                int min_cluster = 1;
                //Using For loop to compute the distance of upcoming clusters

                for (int j = 1; j < K; j++) {
                    double distance = euclidean_distance(array[i][0], array[i][1], array[i][2], centroids[j][0], centroids[j][1], centroids[j][2]);
                    if (distance < min_distance) 
                    {
                        min_distance = distance;
                        min_cluster = j;
                    }

                }
                //Storing values in clusters
                clusters[i] = min_cluster;
            }

            // recalculate the centroids
            for (int i = 0; i < K; i++) 
            {
                double sum_x = 0;
                double sum_y = 0; 
                double sum_z = 0;;
                int count = 0;
                for (int j = 0; j < 200; j++) {
                    if (clusters[j] == i) {
                        sum_x =sum_x + array[j][0];
                        sum_y = sum_y + array[j][1];
                        sum_z = sum_z + array[j][2];
                        count++;
                    }
                }
                //Final computation of centroids
                centroids[i][0] = sum_x / count;
                centroids[i][1] = sum_y / count;
                centroids[i][2] = sum_z / count;
                //For loop ends of computing centroids
            }

        } while (prearr[0][0] == centroids[0][0] && prearr[0][1] == centroids[0][1] && prearr[1][0] == centroids[1][0] && prearr[1][1] == centroids[1][1] && prearr[2][0] == centroids[2][0] && prearr[2][1] == centroids[2][1] && prearr[0][2] == centroids[0][2] && prearr[1][2] == centroids[1][2] && prearr[2][2] == centroids[2][2]);
        cout << "\tValues of Clusters " << endl;
        cout << "\n\n\nClusters Computation Completed .........." << endl;
        for (int i = 0; i < 200; i++)
        {
            cout << "Annual Income : " << array[i][0] << "\Suppporting Income : " << array[i][1] << "\tCluster Value : " << clusters[i] << endl;
        }


        file.close();

        cout << "\n\nClustering After Applying K Mean Algorithm is Completed ." << endl;

        string word;

        fstream in;
        in.open("segmented_customers-1.csv", ios::in);
        fstream out;
        out.open("Question2_data.csv", ios::out | ios::app);
        i = 0;
        bool stop = true;
        int mov = 0;
        while (getline(in, word, '\0'))
        {
            if (stop)
            {
                word += ",";
                word += "Clusters";
                out << word << "\n";
                stop = false;
            }
            else
            {
                word += "," + to_string(clusters[mov]);
                out << word << "\n";
                mov++;
            }
        }
        cout << "\n\n\n\t\tClusters Are Successfully Written Into the File." << endl;

        in.close();
        //Operation are Successsfully Completed
    }
};

