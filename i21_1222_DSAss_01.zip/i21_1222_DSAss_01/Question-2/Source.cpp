//M Mati Ur Rehman
//CS-A
//i21-1222
#include <iostream>
#include <fstream>
#include <string>
#include "..//Question_2/Header.h"
using namespace std;
int main()
{
    //Creating Object of K_Mean_Clustering_Algorithm class
    K_mean_algo object;
    //Calling function to show the output on the screen
    object.k_Mean_clustering();

    return 0;
}