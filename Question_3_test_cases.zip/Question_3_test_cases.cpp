#include "pch.h"
//#include "Header.h"
// Include your header file here

/*
	Question 3 test cases
*/

/*
	Part A
*/

TEST(TPSBasics, CreatingADocument) {
	TPS tps;
	std::string documentName = "newFile.txt"; // Temporary file created
	tps.createNewDocument(documentName);
	tps.addText("Hello.");
	EXPECT_EQ(tps.getDocumentText(documentName), "Hello.");
}

TEST(TPSBasics, ReadingADocument) {
	TPS tps;
	std::string documentName = "testFile1.txt"; // Accompanying file will be provided.
	tps.readDocument(documentName);
	std::string expected_text = "What do you mean?\nYou're asking about this?\nWell...";
	EXPECT_EQ(tps.getDocumentText(documentName), expected_text);
}

TEST(TPSBasics, AddingText) {
	TPS tps;
	std::string documentName = "testFile1.txt";
	tps.readDocument(documentName);
	tps.addText(" This is how we do it./");
	std::string expected_text = "What do you mean?\nYou're asking about this?\nWell... This is how we do it.\n";
	EXPECT_EQ(tps.getDocumentText(documentName), expected_text);
}

TEST(TPSBasics, UndoText) {
	TPS tps;
	std::string documentName = "testFile1.txt";
	tps.readDocument(documentName);
	tps.addText(" This is how we do it.");
	tps.addText("@");
	std::string expected_text = "What do you mean?\nYou're asking about this?\nWell...";
	EXPECT_EQ(tps.getDocumentText(documentName), expected_text);
}

TEST(TPSBasics, RedoText) {
	TPS tps;
	std::string documentName = "testFile1.txt";
	tps.readDocument(documentName);
	tps.addText(" This is how we do it.");
	tps.addText("@");
	tps.addText("#");
	std::string expected_text = "What do you mean?\nYou're asking about this?\nWell... This is how we do it.";
	EXPECT_EQ(tps.getDocumentText(documentName), expected_text);
}

TEST(TPSBasics, RestoringState) {
	TPS tps;
	std::string documentName = "testFile2.txt"; // Accompanying file will be provided.
	tps.readDocument(documentName);
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is.");
	tps.addText(" Good.");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is. Good.");
	tps.addText("@");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is.");
	tps.addText("#");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is. Good.");
	tps.addText("@");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is.");
	tps.addText(" Excellent.");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is. Excellent.");
	tps.addText("#");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is. Excellent.");
	tps.addText("@");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is.");
	tps.addText("^");
	EXPECT_EQ(tps.getDocumentText(documentName), "This course is. Good.");
}

/*
	Part B
*/

TEST(TPSVersionControl, CreatingDocument) {
	TPS tps;
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	EXPECT_TRUE(tps.documentExists(documentName));
}

TEST(TPSVersionControl, SavingTextWithUser) {
	TPS tps;
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	tps.addText("What do you do for living./", documentName, "user1");
	EXPECT_EQ(tps.getDocumentText(documentName), "What do you do for living.\n");
}

TEST(TPSVersionControl, UndoChanges) {
	TPS tps;
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	tps.addText("What do you do for living./", documentName, "user1");
	tps.addText("This is a test./", documentName, "user1");
	tps.undo(documentName, "user1");
	EXPECT_EQ(tps.getDocumentText(documentName), "What do you do for living.\n");
}

TEST(TPSVersionControl, RedoChanges) {
	TPS tps;
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	tps.addText("What do you do for living./", documentName, "user1");
	tps.addText("This is a test2./", documentName, "user1");
	tps.undo(documentName, "user1");
	tps.redo(documentName, "user1");
	EXPECT_EQ(tps.getDocumentText(documentName), "What do you do for living.\nThis is a test2.\n");
}

TEST(TPSVersionControl, SaveVersion) {
	TPS tps;
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	tps.addText("How's the assignment!/", documentName, "user1");
	tps.addText("This is a test./", documentName, "user1");
	EXPECT_TRUE(tps.versionExists("user1", documentName));
	EXPECT_EQ(tps.getVersion("user1", documentName)), "How's the assignment!\nThis is a test.\n"); 
}

TEST(TPSVersionControl, RestoreVersion) {
	TPS tps("admin"); // Log in as admin
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	tps.addText("How's the assignment!/", documentName, "user1");
	tps.addText("This is a test./", documentName, "user1");
	tps.addText("Some more text./", documentName, "user1");
	tps.restoreVersion("user1", documentName);
	EXPECT_EQ(tps.getDocumentText(documentName), "How's the assignment!\n");
}

TEST(TPSVersionControl, SeeHistory) {
	TPS tps("admin");
	std::string documentName = "doc.txt";
	tps.createNewDocument(documentName);
	tps.addText("How's the assignment!/", documentName, "user1");
	tps.addText("This is a test./", documentName, "user2");
	tps.addText("Some more text./", documentName, "user1");
	std::string *history = tps.getTextHistory("user1", documentName);
	EXPECT_EQ(history[0], "How's the assignment!\n");
	EXPECT_EQ(history[1], "How's the assignment!\nSome more text.\n");
}

/*
	Part C
*/

TEST(TPSSearching, BFS) {
	TPS tps("admin");
	std::string documentName = "bfs.txt";
	tps.createNewDocument(documentName);
	tps.addText("Just a small text I whipped up,/", documentName, "user1");
	tps.addText("Hope nobody makes a change to it.", documentName, "user1");
	tps.addText("I've changed your document.", documentName, "user2");
	tps.addText("Well I hope this doesn't affect the test case in any manner.", documentName, "user1");
	tps.addText("Not if you code properly!", documentName, "user2");
	tps.addText("Right...", documentName, "user1");
	// Initialise a queue that contains the version histories of all users
	Queue searchHistory = tps.BFS();
	// Check if all versions are in order of user 1 (all of their version changes), then user 2 (all of their version changes)
	// Be careful - All of the changes are done in the same document!
	std::string expected_answer = "Just a small text I whipped up,\n";
	EXPECTED_EQ(searchHistory.dequeue(), expected_answer);
	expected_answer = "Just a small text I whipped up,\nHope nobody makes a change to it.";
	EXPECTED_EQ(searchHistory.dequeue(), expected_answer);
	expected_answer = "Just a small text I whipped up,\nHope nobody makes a change to it.I've changed your document.Well I hope this doesn't affect the test case in any manner.";
	EXPECTED_EQ(searchHistory.dequeue(), expected_answer);
	expected_answer = "Just a small text I whipped up,\nHope nobody makes a change to it.I've changed your document.Well I hope this doesn't affect the test case in any manner.Not if you code properly!Right...";
	EXPECTED_EQ(searchHistory.dequeue(), expected_answer);
	expected_answer = "Just a small text I whipped up,\nHope nobody makes a change to it.I've changed your document.";
	EXPECTED_EQ(searchHistory.dequeue(), expected_answer);
	expected_answer = "Just a small text I whipped up,\nHope nobody makes a change to it.I've changed your document.Well I hope this doesn't affect the test case in any manner.Not if you code properly!";
	EXPECTED_EQ(searchHistory.dequeue(), expected_answer);
}

TEST(TPSSearching, DFS) {
	TPS tps("admin");
	std::string documentName = "dfs.txt";
	tps.createNewDocument(documentName);
	tps.addText("My most favourite sonnet of all time happens to be of Edgar Allan Poe's 'To My Mother'.", documentName, "user1");
	tps.addText(" Do tell about it.", documentName, "user3");
	tps.addText(" I've unfortunately forgotten about it.", documentName, "user1");
	tps.addText(" I remember how a part of it goes:", documentName, "user2");
	tps.addText(" 'Because I feel that, in the Heavens above,", documentName, "user2");
	tps.addText(" The angels, whispering to one another", documentName, "user2");
	tps.addText(" Can find, among their burning terms of love,", documentName, "user2");
	tps.addText(" None so devotional as that of Mother,'.", documentName, "user2");
	// Initialise a queue that contains the version histories of all users
	Stack searchHistory = tps.DFS();
	// Check if all versions are in order of first changes by all users, then second changes by all users, and so on.
	// Be careful - All of the changes are done in the same document!
	std::string expected_answer = "My most favourite sonnet of all time happens to be of Edgar Allan Poe's 'To My Mother'.";
	EXPECT_EQ(searchHistory.pop(), expected_answer);
	expected_answer = "My most favourite sonnet of all time happens to be of Edgar Allan Poe's 'To My Mother'. Do tell about it.";
	EXPECT_EQ(searchHistory.pop(), expected_answer);
	expected_answer = "My most favourite sonnet of all time happens to be of Edgar Allan Poe's 'To My Mother'. Do tell about it. I've unfortunately forgotten about it. I remember how a part of it goes: 'Because I feel that, in the Heavens above, The angels, whispering to one another, Can find, among their burning terms of love, None so devotional as that of Mother,'.";
	EXPECT_EQ(searchHistory.pop(), expected_answer);
	expected_answer = "My most favourite sonnet of all time happens to be of Edgar Allan Poe's 'To My Mother'. Do tell about it. I've unfortunately forgotten about it.";
	EXPECT_EQ(searchHistory.pop(), expected_answer);
}