/*
M Mati Ur Rehman
i21-1222
Assignment 2
CS-A
*/

#include <iostream>
#include <fstream>

using namespace std;

// Node structure for the singly linked list
class StringList {
public:
    char alphabet;
    StringList* next;
    //Creating Default constructor of String List Class
    StringList() {
        alphabet = 0;
        next = NULL;
    }
    //Creating Parametrized constructor of String List Class
    StringList(char data) {
        this->alphabet = data;
        this->next = NULL;
    }
};
//Find Length function of the whole String Manipulation
int find_Length(StringList* s, int counter) //counter will start from zero initially
{
    //cout << counter << endl;
    //Uisng if else to chec that string equals to NULL or not 
    if (s == NULL)
    {
        //if yess that counterr++ and we assume that length is this
        counter++;
        return counter;
    }
    else
    {
        //if yess that counterr++ and we assume that length is this
        //counter++;
        //Using return type to check recursively that lenght of string is this
        return find_Length(s->next, counter + 1);
    }
}
class String_Manipulation {
public:
    StringList* next;
    StringList* prev;
    String_Manipulation()
    {
        next = NULL;
        prev = NULL;
    }
   
    
    // Function to create the linked list from a file
    void createList(StringList* head) {
        //Declaring Some variable of file and counter to perform opeartions on the Create List
        ifstream file;
        int count = 0;
        //Usng open fnction to open the file paragrag txt and perform operations on the adata
        file.open("Paragraph.txt");
        char ch;
        //using for loop noskipws function to read data from the file and putt it on the scereen 
        while (file >> noskipws >> ch) {
            //cout << ch;
            //using count+++ to calculate length generically
            count++;
            //Declaring node based pomiter and pass character to the node and then see what happens
            StringList* node = new StringList(ch);
            //now node alphabet is required to check character is up and proceed for the nexrt process
            node->alphabet = ch;
            node->next = NULL;
            //using if else to check node is NULL or not is not odo this else do this
            if (head == NULL) {
                head = node;
            }
            //using if else to check node is NULL or not is not odo this else do this
            else {
                StringList* temp = head;
                //Using for loop to check credentials
                for (; temp->next != NULL;) {
                    temp = temp->next;
                    
                }
                temp->next = node;
            }
        }
        cout << "\nLength: " <<count<< endl;
        //length(count);
        cout << endl;
        //Closing file
        file.close();
    }

    // Recursive function to calculate the length of the linked list
    int Calculate_length(StringList* head) {
        //head = NULL;
        //cout << head->alphabet << endl;
        int count=0;
        int count1;
        StringList* s = head;
       // if (head == NULL) {
           // cout<<"If Call in Calculate length" << endl;
          //  return 0;
        //}
        //else
       // {
        //cout << "hello" << s->alphabet << endl;
            count1= find_Length(s, count);
            cout << "Count: " << count1 << endl;
        //}
        return count;
            
    }

    // Function to check if a given string exists in the linked list
    bool substring(StringList* head, string str) {
        cout << "Calling SubString" << endl;
        int n = str.length();
        StringList* temp = head;

        while (temp) {
            int i = 0;
            //Declare the current pointer and equals to the head and perform operation on that
            StringList* current = temp;
            //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
            for (; current != NULL && i < n && current->alphabet == str[i];) {
                current = current->next;
                i++;
            }
            //using if else to check its true or not
            if (i == n) {
                return true;
            }
            temp = temp->next;
        }
        return false;
    }

    // Function to find the index of a given substring in the linked list
    int substring_position(StringList* head, string str) {
        //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
        int n = str.length();
        //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
        StringList* temp = head;
        int index = 0;
        //Declare the current pointer and equals to the head and perform operation on that
        while (temp) {
            int i = 0;
            StringList* current = temp;
            //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
            for (; current != NULL && i < n && current->alphabet == str[i];) {
                //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
                current = current->next;
                i++;
            }
            //using if else to check its true or not
            if (i == n) {
                return index;
            }
            //using if else to check its true or not
            temp = temp->next;
            index++;
        }
        //The function returning -1 to the data
        return -1;
    }

    // Function to replace a given string with another string in the linked list
    void replaceString(StringList* head, string find, string replace) {
        //Declare the current pointer and equals to the head and perform operation on that
        int n1 = find.length();
        //Declare the current pointer and equals to the head and perform operation on that
        int n2 = replace.length();
        //Declare the current pointer and equals to the head and perform operation on that
        StringList* temp = head;
        while (temp != NULL) {
            int i = 0;
            StringList* current = temp;
            //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
            for (; current != NULL && i < n1 && current->alphabet == find[i];) {
                current = current->next;
                i++;
            }
            //using if else to check its true or not
            if (i == n1) {
                // Found the substring, replace it with the new string
                current = temp;
                int j = 0;
                //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
                for (; j < n2;) {
                    current->alphabet = replace[j];
                    current = current->next;
                    j++;
                }
                temp = current;
            }
            //using if else to check its true or not
            else {
                temp = temp->next;
            }
        }
    }
    /*
        // Function to append a string to the linked list at a given index
        void appendText(StringList* head, string appends, int index) {
            int n = appends.length();
            StringList* temp = head;
            int i = 0;
            */
            // Append a string in string list at given index
    void appendText(StringList* head, string appends, int index) {
        StringList* current = head;
        StringList* prev = nullptr;

        // Traverse the list until we reach the desired index
         //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
        for (int i = 0; i < index && current != nullptr; i++) {
            prev = current;
            current = current->next;
        }

        // Create nodes for the appended string
        StringList* tail = nullptr;
        //using for loop to check credentails on the data and then check wheateher th e stringi svalid or not
        
        int kill = 0;
        while ( kill < appends.length()) {
            StringList* newNode = new StringList;
            newNode->alphabet = appends[kill];
            newNode->next = nullptr;
            //using if else to check its true or not
            if (tail == nullptr) {
                tail = newNode;
            }
            //using if else to check its true or not
            else {
                tail->next = newNode;
                tail = newNode;
            }
            kill++;
        }

        // Append the new nodes to the list
        if (prev != NULL)
        {
            prev->next = tail;
        }
        if (prev == nullptr) {
            head = tail;
        }
        else {
            prev->next = tail;
        }
        //Noe pointeing tail to next of head
        tail->next = current;
    }

};



int main() {
    StringList* head=NULL;
    StringList* temp = head;
    String_Manipulation sm;
    
    sm.createList(temp);
    temp = head;
    //cout << "Tepm: " << temp->data << endl;
    int c = sm.Calculate_length(temp);
    //Output the length of paragraph to the screen
    cout << "Length of string: " << c << endl;

    string str;
    //Output the length of paragraph to the screen
    cout << "Enter substring to search: ";
    cin >> str;
    //Using if/else to check the substrin on the paragraph
    if (sm.substring(head, str)) {
        cout << "Substring exists." << endl;
        cout << "Position of substring: " << sm.substring_position(head, str) << endl;
    }
    //Using if/else to check the substrin on the paragraph
    else {
        cout << "Substring does not exist." << endl;
    }
    //Using if/else to check the substrin on the paragraph
    string find, replace;
    cout << "Enter substring to replace: ";
    cin >> find;
    cout << "Enter substring to replace with: ";
    cin >> replace;
    sm.replaceString(head, find, replace);

    string appends;
    int index;
    cout << "Enter string to append: ";
    cin >> appends;
    cout << "Enter index to append at: ";
    cin >> index;
    sm.appendText(head, appends, index);

    // string delText;
    // cout << "Enter string to delete: ";
    // cin >> delText;
    // sm.deleteText(head, delText);

    // Print the updated string
    StringList* curr = head;
    //Using for lopp to check the daat and print ot on the screnn
    for (; curr != nullptr;) {
        cout << curr->alphabet;
        curr = curr->next;
    }
    cout << endl;
    return 0;
}

