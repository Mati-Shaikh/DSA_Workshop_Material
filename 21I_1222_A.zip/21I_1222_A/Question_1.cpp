/*
M Mati Ur Rehman
I21-1222
Assignment-2
CS-A
*/
#include <iostream>
using namespace std;
class student_Node
{
public:
    string name;
    student_Node* next;
    student_Node(string name)
    {
        this->name = name;
        next = NULL;
    }
};
//Creating insertNode of Node type to insert Students in the linked List
student_Node* insertNode(student_Node* head, string name)
{
   //Declare newNode pointer And current pointer to perform Operation on the data
    student_Node* newNode = new student_Node(name);
    student_Node* curr = head;
    //Uisng if to chect credentials on the data
    if (head != NULL)
    {
        for (;curr->next != nullptr;)
        {
            curr = curr->next;
        }
        curr->next = newNode;
    }
    //Using else if head equals to NULL then perform this operation
    else
    {
        head = newNode;
    }
    return head;
}

//Function To return List of all Students in the society
string* list_all_students(student_Node* head1, student_Node* head2, student_Node* head3)
{
    // Count the total number of students
    int count = 0;
    student_Node* current;
    //Using for loop to point the data in the first list of head1
    current = head1;
    for (; current != NULL;)
    {
        count++;
        current = current->next;
    }
    //Using while loop to point the data in the first list of head1
    current = head2;
    while (current != NULL)
    {
        count++;
        current = current->next;
    }
    //Using while loop to point the data in the third list of head3
    current = head3;
    while (current != NULL)
    {
        count++;
        current = current->next;
    }

    // Create an array to store the student names
    string* result = new string[count];

    // Fill the array with the student names
    int i = 0;
    //Using while loop to enter the in the resultant string
    current = head1;
    while (current != NULL)
    {
        result[i] = current->name;
        i++;
        current = current->next;
    }
    //Using while loop to enter the in the resultant string
    current = head2;
    for (; current != NULL;)
    {
        result[i] = current->name;
        i++;
        current = current->next;
    }
    //Using while loop to enter the in the resultant string
    current = head3;
    for (; current != NULL;)
    {
        result[i] = current->name;
        i++;
        current = current->next;
    }
    //Using while loop to enter the in the resultant string
    cout << "Names of all students : " << endl;
    for (int i = 0; i < count; i++)
    {
        cout << result[i] << " ";
    }
    return result;
}
//Function to return common of all the students in the linked list
string* list_common_student_society(student_Node* head1, student_Node* head2, student_Node* head3)
{
    cout << "Calling List of Common Students" << endl;
    // Count the number of common students
    int count = 0;
    //Creating three node based list and point all these to the heads of their own
    student_Node* current1;
    student_Node* current2;
    student_Node* current3;

    current1 = head1;
    //Using for loop to check credentials on the List
    for (;current1 != NULL;)
    {
        //Now Creating current2 equals to head2 and make operations on the list
        current2 = head2;

        while (current2 != NULL)
        {
            //Now Creating current2 equals to head2 and make operations on the list
            if (current1->name == current2->name)
            {
                //Now Creating current2 equals to head2 and make operations on the list
                current3 = head3;
                //Using for loop to check credentials on the List
                for (;current3 != NULL;)
                {
                    //Using if to check wheather name is equals to the name or not
                    if (current1->name == current3->name)
                    {
                        count++;
                        break;
                    }
                    //Using for loop to check credentials on the List
                    current3 = current3->next;
                }
                break;
            }
            //Now Creating current2 equals to head2 and make operations on the list
            current2 = current2->next;
        }
        //Now Creating current2 equals to head2 and make operations on the list
        current1 = current1->next;
    }

    // Create an array to store the common student names
    string* result = new string[count];

    // Fill the array with the common student names
    int i = 0;
    //Now Creating current2 equals to head2 and make operations on the list
    current1 = head1;
    while (current1 != NULL)
    {
        //Now Creating current2 equals to head2 and make operations on the list
        current2 = head2;
        while (current2 != NULL)
        {
            //Now Creating current2 equals to head2 and make operations on the list
            if (current1->name == current2->name)
            {
                //Now Creating current2 equals to head2 and make operations on the list
                current3 = head3;
                //Using for loop to perform operations on the List data
                for (;current3 != NULL;)
                {
                    //Now Creating current2 equals to head2 and make operations on the list
                    if (current1->name == current3->name)
                    {
                        result[i] = current1->name;
                        i++;
                        break;
                    }
                    //Now Creating current2 equals to head2 and make operations on the list
                    current3 = current3->next;
                }
                break;
            }
            //Now Creating current2 equals to head2 and make operations on the list
            current2 = current2->next;
        }
        //Now Creating current2 equals to head2 and make operations on the list
        current1 = current1->next;
    }

    //cout<<"Common : "<<endl;
    //Using for loop to print the data on the screen and showing that these are the common name i the list
    for (int j = 0; j < count; j++)
    {
        cout << result[i];
    }

    return result;
}
//Creating Print List Function
void printList(student_Node* head)
{
    student_Node* curr = head;
    while (curr)
    {
        cout << curr->name << " ";
        curr = curr->next;
    }
    cout << endl;
}


int main()
{
    student_Node* FGS_List = nullptr;
    student_Node* FAS_List = nullptr;
    student_Node* FDS_List = nullptr;

    student_Node* head1 = nullptr;
    student_Node* head2 = nullptr;
    student_Node* head3 = nullptr;

    string* result;
    int size;

    int choice;
    string name;
    do
    {
        // Design a menu for a FAST Society
        cout << "\n\n\t\tWELCOME TO FAST SOCIETY MANAGEMENT" << endl;
        cout << "\t\tFROM WHICH SOCIETY TO PARTICIPATE IN?" << endl;
        cout << "1 : FAST GAMING SOCIETY (FGS)" << endl;
        cout << "2 : FAST ADVENTURE SOCIETY (FAS)" << endl;
        cout << "3 : FAST DRAMATIC SOCIETY (FDS)" << endl;
        cin >> choice;

        // do
        //{
        switch (choice)
        {
        case 1:
            cout << "Enter the name of the student: ";
            cin >> name;
            FGS_List = insertNode(head1, name);
            head1 = FGS_List;
            printList(FGS_List);
            break;

        case 2:
            cout << "Enter the name of the student: ";
            cin >> name;
            FAS_List = insertNode(head2, name);
            head2 = FAS_List;
            printList(FAS_List);
            break;

        case 3:
            cout << "Enter the name of the student: ";
            cin >> name;
            FDS_List = insertNode(head3, name);
            head3 = FDS_List;
            printList(FDS_List);
            break;

        default:
            cout << "\n\t\tINVALID INPUT \nPLEASE ENTER VALID INPUT: " << endl;
            break;
        }

        cout << "\n\t\tDo you want to continue?\n\t\t1. Yes\n\t\t2. No" << endl;
        cin >> choice;

    } while (choice == 1);

    // Print all students
    cout << "\n\n\t\tALL STUDENTS" << endl;
    result = list_all_students(FGS_List, FAS_List, FDS_List);


    //cout<<result[0];
    //print_result(result,size);
    // cout<<*result;
    //printList(result);

    // Print common students
    cout << "\n\n\t\tCOMMON STUDENTS" << endl;
    result = list_common_student_society(FGS_List, FAS_List, FDS_List);
    //print_result(result,size);
    cout << "FGS Sciety Students" << endl;
    printList(FGS_List);
    cout << "FAS Sciety Students" << endl;
    printList(FAS_List);
    cout << "FDS Sciety Students" << endl;
    printList(FDS_List);
    // fill all llist
    // call both funcations
    // print results;

    return 0;
}
