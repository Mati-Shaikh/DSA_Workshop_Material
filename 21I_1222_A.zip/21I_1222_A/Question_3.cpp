/*
M Mati Ur Rehman
I21-1222
Cs-A
Assignment-2
*/
/*----------Question-3 (LIFT AUMATION SYSTEM)-----------------*/
#include <iostream>
using namespace std;
// Creating class of lift_floors
class lift_floors
{
public:
    int floor;
    char floor_status; // A for active N for not active
    bool operational;
    lift_floors *next;
    lift_floors *prev;

    // Creating Default Constructor
    lift_floors()
    {
        floor = 0;
        operational = true;
        next = NULL;
        prev = NULL;
    }
    // Creating Parametrized Constructor
    lift_floors(int data)
    {
        this->floor = data;
        this->floor_status = 'A';
        operational = true;
        next = NULL;
        prev = NULL;
    }
};

// Now Creating Function ProtoTypes of List Automation System

int lift_operating_system(int requested_floor, lift_floors *current, lift_floors *head, lift_floors *tail, char lift_status);
int liftup(lift_floors *current, lift_floors *head, lift_floors *tail, int requested_floor);
int liftdown(lift_floors *current, lift_floors *head, lift_floors *tail, int requested_floor);
char halt_lift(char status);
char un_halt_lift(char status);
void add_floor(lift_floors *new_floor, lift_floors *head, lift_floors *tail);
void skip_floor(lift_floors *head, lift_floors *tail, int floorNo);
void make_floor_operational(lift_floors *head, lift_floors *tail, int floorNo);

// Now Creating Main function

int main()
{
    //Declaring lift_floors and premitive data types to perform operations on the Lift Automation
    lift_floors *head = NULL;
    lift_floors *tail = NULL;
    lift_floors *current = NULL;
    //Declaring lift_floors and premitive data types to perform operations on the Lift Automation
    int total_floors = 6;   // total number of floors
    int current_floor = -1; // starts with basement
    int requested_service;  // choice of user
    int requested_floor;    // floor the lift goes on
    char status = 'W';      // W for working , H for halted

    // initialize the lift floors
    lift_floors *basement = new lift_floors();
    basement->floor = -1;
    basement->operational = true;
    basement->next = nullptr;
    // initialize the lift floors
    lift_floors *floor0 = new lift_floors();
    floor0->floor = 0;
    floor0->operational = true;
    floor0->prev = basement;
    basement->next = floor0;
    // initialize the lift floors
    lift_floors *floor1 = new lift_floors();
    floor1->floor = 1;
    floor1->operational = true;
    floor1->prev = floor0;
    floor0->next = floor1;
    // initialize the lift floors
    lift_floors *floor2 = new lift_floors();
    floor2->floor = 2;
    floor2->operational = true;
    floor2->prev = floor1;
    floor1->next = floor2;
    // initialize the lift floors
    lift_floors *floor3 = new lift_floors();
    floor3->floor = 3;
    floor3->operational = true;
    floor3->prev = floor2;
    floor2->next = floor3;
    // initialize the lift floors
    lift_floors *floor4 = new lift_floors();
    floor4->floor = 4;
    floor4->operational = true;
    floor4->prev = floor3;
    floor3->next = floor4;
    // initialize the lift floors
    tail = new lift_floors();
    tail->floor = 5;
    tail->operational = false;
    tail->prev = floor4;
    floor4->next = tail;
// initialize the lift floors
    head = basement;
    current = basement;
//using while loop to show menu and perform opeartions on the data
    while (1)
    {
        //Declaring Menu of Lift Automation system
        int choice;
        cout << "\n Please Select a funcation of your choice" << endl;
        cout << "1. Go to a floor" << endl;
        cout << "2. Halt the lift" << endl;
        cout << "3. Unhalt the lift" << endl;
        cout << "4. Add floor" << endl;
        cout << "5. Skip floor" << endl;
        cout << "6. Make floor operational" << endl;
        cout << "7. Exit" << endl;
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            int requested_floor;
            cout << "Enter the floor you want to go to (-1 to 4): ";
            cin >> requested_floor;
            if (requested_floor < -1 || requested_floor > 4)
            {
                cout << "Invalid floor selection. Please try again." << endl;
            }
            else if (status == 'H')
            {
                cout << "The lift is currently halted. Please unhalt it before making any lift requests." << endl;
            }
            else
            {
                lift_operating_system(requested_floor, current, head, tail, status);
                cout << "The lift is now on floor " << requested_floor << "." << endl;
            }
            break;
        }
        case 2:
        {
            status = halt_lift(status);
            cout << "The lift is now halted." << endl;
            break;
        }

        case 3:
        {
            status = un_halt_lift(status);
            cout << "The lift is now operational." << endl;
            break;
        }
        case 4:
        {
            int floorNo;
            cout << "Enter the new floor number: ";
            cin >> floorNo;
            lift_floors *new_floor = new lift_floors;
            new_floor->floor = floorNo;
            new_floor->next->next->prev = nullptr;
            new_floor->next->prev->prev = nullptr;
            add_floor(new_floor, head, tail);
            break;
        }

        case 5:
        {
            int floorNo;
            cout << "Enter the floor number to skip: ";
            cin >> floorNo;
            skip_floor(head, tail, floorNo);
            break;
        }

        case 6:
        {
            int floorNo;
            cout << "Enter the floor number to make operational: ";
            cin >> floorNo;
            make_floor_operational(head, tail, floorNo);
            break;
        }
        case 7:
        {
            exit(0);
        }
        default:
        {
            cout << "Invalidation" << endl;
        }
        }
    }
    return 0;
}

int lift_operating_system(int requested_floor, lift_floors *current, lift_floors *head, lift_floors *tail, char lift_status)
{
    // check if lift is halted
    if (lift_status == 'H')
    {
        cout << "Lift is currently halted. Please unhalt the lift to continue." << endl;
        return current->floor;
    }

    // check if requested floor is the current floor
    if (requested_floor == current->next->prev->floor)
    {
        cout << "You are already on the requested floor." << endl;
        return current->floor;
    }

    // check if requested floor is operational
    if (!current->operational)
    {
        cout << "The lift cannot go to this floor as it is not operational." << endl;
        return current->floor;
    }

    // determine direction of travel
    int direction = requested_floor - current->floor;
    if (direction > 0)
    {
        // go up
        int new_floor = liftup(current, head, tail, requested_floor);
        cout << "Lift went up to floor " << new_floor << endl;
        return new_floor;
    }
    else
    {
        // go down
        int new_floor = liftdown(current, head, tail, requested_floor);
        cout << "Lift went down to floor " << new_floor << endl;
        return new_floor;
    }
    cout << "Operating system Function" << endl;
}

char halt_lift(char status)
{
    status = 'H';
    return status;
}

// function to unhalt the lift
char un_halt_lift(char status)
{
    status = 'W';
    return status;
}

// function to skip a floor
void skip_floor(lift_floors *head, lift_floors *tail, int floorNo)
{
    //Creating current floor and equals it to the head
    lift_floors *current = head;
    //while (current)
    for(;current;)
    {
        //using if else to perform operation on the data
        if (current->floor == floorNo)
        {
            current->operational = false;
            break;
        }
        current = current->next;
    }
}

// function to make a floor operational
void make_floor_operational(lift_floors *head, lift_floors *tail, int floorNo)
{
    //Creating current floor and equals it to the head
    lift_floors *current = head;
    for (; current;)
    {
        //using if else to perform operation on the data
        if (current->floor == floorNo)
        {
            current->operational = true;
            break;
        }
        current = current->next;
    }
}

// recursive function to move the lift up
int liftup(lift_floors *current, lift_floors *head, lift_floors *tail, int requested_floor)
{
    if (current->floor == requested_floor)
    {
        return current->floor;
    }
    if (current == NULL || current->next == NULL)
    {
        return -1;
    }
    if (current->next->operational)
    {
        return liftup(current->next, head, tail, requested_floor);
    }
    else
    {
        return -1;
    }
}

// recursive function to move the lift down
int liftdown(lift_floors *current, lift_floors *head, lift_floors *tail, int requested_floor)
{
    if (current->next->prev == NULL || current->next->prev->prev == NULL)
    {
        return -1;
    }
    if (current->next->prev->floor == requested_floor)
    {
        return current->floor;
    }
    if (current->prev->operational)
    {
        return liftdown(current->prev, head, tail, requested_floor);
    }
    else
    {
        return -1;
    }
}

// function to add a new lift floor
void add_floor(lift_floors *new_floor, lift_floors *head, lift_floors *tail)
{
    if (head != NULL || tail != NULL)
    {
        tail->next = new_floor;
        new_floor->prev = tail;
    }
    else
    {
        tail = new_floor;
        head = new_floor;
        tail = new_floor;
    }
}