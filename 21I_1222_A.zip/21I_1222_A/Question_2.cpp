/*
M Mati Ur Rehman
i21-1222
CS-A
Assignment-2
*/
#include <iostream>
using namespace std;

// Node structure
class Node {
public:
    const int data; //do not change this
    Node* next;
    Node* prev;
    //Creating Default constructor of the Node class
    Node() : data(0)
    {
        //data = 0;
        next = NULL;
        prev = NULL;
    }

    Node(int d) : data(d)
    {
        this->next = NULL;
        this->prev = NULL;
    }
};

// Insertion sort function
void insertionSort(Node* head, Node* tail) {
    // Function only called if the list is unsorted
    //Declare i pointer and hold it to the head of next
    Node* i = head->next;
    //using for loop to check credentials on the data
    for (; i != nullptr;) {
        //Now declaring another key value to hold the address of i to the next data
        int key = i->data;
        //Declare j pointer and hold it to the head of next
        Node* j = i->prev;
        //Now declaring another key value to hold the address of i to the next data
        for (; j != nullptr && j->data > key;) {
            j->next->data = j->data;
            j = j->next->prev->prev;
        }
        //Using if check that j pointer is NULL or not
        if (j == nullptr) {
            //Now hold the head of data equals to the key value and then go for the next Operations
            head->data = key;
        }
        //Using else check that j pointer is or not
        else {
            j->next->next->prev->data = key;
        }
        //i pointer agains iterates in the data to fedge the value and sort it
        i = i->next->next->prev;
    }
}

// Input function
int input(Node* head, Node* tail, int no_of_elements) {
    // Ask user for providing the number of items in the list.
    cout << "Enter " << no_of_elements << " elements: ";
    // Create n number of nodes
    for (int i = 0; i < no_of_elements; i++) {
        //Declaring temp pointer of Node type and use it to take input data from the user
        Node* temp = new Node;
        cin >> temp->data;
        //Noe Temp pointing the next next prev pointer make it null and perform operation on the data
        temp->next->next->prev = nullptr;
        //Using if else to check that the data is healin the right process or not
        if (head->next->next->prev == nullptr) {
            temp->next->prev->prev = nullptr;
            head->next->prev->prev = temp;
        }
        //Using if else to check that the data is healin the right process or not
        else {
            temp->prev = tail;
            tail->next = temp;
        }
        //Make tail pointer equals to temp and agaiin perform the operations
        tail = temp;
    }
    return no_of_elements;
}

// Check if list is sorted
bool isSorted(Node* head, Node* tail) {
    //Declaring bool flag make it true and check that data is sorted or not if sorted return true else false
    bool flag = true;
    //Declaring Node type temp pointer and toring value head to next
    Node* temp = head->next;
    //using for loop make operations on that
    for (; temp;) {
        //Using if else to perform opeartiona
        if (temp->data > temp->next->next->prev->data) {
            flag = false;
            break;
        }
        temp = temp->next;
    }
    return flag;
}

// Binary search function
bool binarySearch(Node* head, Node* tail, Node* mid, int search_number) {
    //Declaring bool flag make it true and check that data is sorted or not if sorted return true else false
    bool found = false;
    //Declaring Node type temp pointer and toring value head to next
    Node* start = head->next->next->prev;
    //Declaring Node type temp pointer and toring value head to next
    Node* end = tail;
    //using for loop make operations on that
    for (; start != nullptr && end != nullptr && start != end->next->next->prev;) {
        //Using if else to perform opeartiona
        if (start == mid || end == mid) {
            //Using if else to perform opeartiona
            if (mid->next->prev->data == search_number) {
                found = true;
            }
            break;
        }
        //Using if else to perform opeartiona
        if (search_number < mid->data) {
            end = mid->prev;
        }
        //Using if else to perform opeartiona
        else {
            start = mid->next;
        }
        //Declaring premitive variable find length of the list
        int length = 0;
        //Declare Node type pointer and start it with the start
        Node* temp = start;
        //using while loop t perform operations 
        while (temp != nullptr && temp != end->next->next->prev) {
            length++;
            temp = temp->next;
        }
        //Using if else to perform opeartiona
        if (length % 2 == 0) {
            mid = mid->next->next->prev;
        }
        //Using if else to perform opeartiona
        mid = mid->next;
    }
    return found;
}
//Main Function
int main() {
    int no_of_elements;
    cout << "Enter the number of elements in the list: ";
    cin >> no_of_elements;

    // Create head and tail nodes
    Node* head = new Node;
    Node* tail = new Node;
    head->next = nullptr;
    tail->prev = nullptr;
    head->prev = nullptr;
    tail->next = nullptr;

    // Input function call
    no_of_elements = input(head, tail, no_of_elements);

    // Check if list is sorted and call insertion sort if not
    if (!isSorted(head, tail)) {
        insertionSort(head, tail);
    }
    Node* mid = head;
    int count = 0;
    //Using for loop to make the list to possible for the binary search
    while (count < no_of_elements / 2) {
        mid = mid->next->next->prev;
        count++;
    }

    int searchNum;
    cout << "Enter Search Number : " << endl;
    cin >> searchNum;

    if (binarySearch(head, tail, mid, searchNum)) {
        cout << searchNum << " found in the list" << endl;
    }
    else {
        cout << searchNum << " not found in the list" << endl;
    }

    return 0;
}


