/*
i21_1222
M Mati Ur Rehman
CS_A
Assignment_4
*/
//-------------------------------Question-2------------------------------
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include"Header.h"

using namespace std;
using namespace cv;

void build_image(Quad_Tree* quad, Mat& img)
{
    switch (quad->data) {
    case 2:
        // Do nothing if obj->data equals 2
        break;
    default:
        int foo = quad->top_Left.x, foo1 = quad->top_Left.y, zoo = quad->bottom_Right.x, zoo1 = quad->bottom_Right.y;
        int i = foo;
        while (i < zoo)
        {
            int j = foo1;
            while (j < zoo1)
            {
                img.ptr(i, j)[0] = quad->data;
                img.ptr(i, j)[1] = quad->data;
                img.ptr(i, j)[2] = quad->data;
                j++;
            }
            i++;
        }
        break;
    }

    switch (quad->top_L_Tree != NULL) {
    case true:
        build_image(quad->top_L_Tree, img);
        break;
    default:
        break;
    }

    switch (quad->top_R_Tree != NULL) {
    case true:
        build_image(quad->top_R_Tree, img);
        break;
    default:
        break;
    }

    switch (quad->bottom_L_Tree != NULL) {
    case true:
        build_image(quad->bottom_L_Tree, img);
        break;
    default:
        break;
    }

    switch (quad->bottom_R_Tree != NULL) {
    case true:
        build_image(quad->bottom_R_Tree, img);
        break;
    default:
        break;
    }
}


int main()
{

    int rows, cols;
    int** array = read_from_file(rows,cols);
    Axis obj(0, 0), obj1(rows, cols);
    Quad_Tree quad(obj, obj1),quad1(obj,obj1);
    cout << "Rows In This Picture : " << rows << "  " << "Columns In This Picture : " << cols << endl;
    cout << "\n\n\tSuucessfully Data has been converted into Quad Trees." << endl;
    quad.InsertToQuadTree(array);
    Mat img(cols, rows, CV_8UC3, Scalar(0, 0, 0));
    build_image(&quad,img);
    imwrite("MyPhoto.bmp", img);
    cout << "\n\tCongratulation Image has been Successfully made by name as (MyPhoto)." << endl;

}