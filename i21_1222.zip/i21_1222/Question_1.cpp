/*
i21_1222
M Mati Ur Rehman
CS_A
Assignment_4
*/
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include"Header.h"

using namespace std;
using namespace cv;
void main_function()
{
    //read an image from the folder
    Mat img = imread("t5.bmp");
    //declare an rows and cols and read their rows and cols
    int rows = img.rows;
    int cols = img.cols;
    //Declare the objects of Axis and Quad_Trees
    Axis obj(0, 0), obj1(rows, cols);
    Quad_Tree obj3(obj, obj1);
    cout << "Rows In This Picture : " << rows << "  " << "Columns In This Picture : " << cols << endl;
    //Declare the 2D array and work it in the loop
    int** array = new int* [rows];
    int i = 0;
    while (i < rows)
    {
        array[i] = new int[cols];
        i++;
    }
    //using for loop to convert it in the 2D Array
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            array[i][j] = img.ptr(i, j)[0];
        }
    }
    //Calling functions 
    convert_To_2d_LL(array, rows, cols);
    obj3.InsertToQuadTree(array);
    obj3.written_into_the_file();
    //obj3.written_In_Files();
    cout << "The Data of Quad Tree has been succesfully stored in files." << endl;

}

int main()
{
   //Calling main function
    main_function();
}

