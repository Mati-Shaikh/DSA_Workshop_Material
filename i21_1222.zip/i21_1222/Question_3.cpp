/*
i21_1222
M Mati Ur Rehman
CS_A
Assignment_4
*/
//////------------------------------------Question-3------------------------------
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include"Header.h"

using namespace std;
using namespace cv;


float compare_Images_accuratly(Mat img_1, Mat img_2)
{
    int rows_1 = img_1.rows, cols_1 = img_1.cols, rows_2 = img_2.rows, cols_2 = img_2.cols;

    int** array_1 = new int* [rows_1];
    int** array_2 = new int* [rows_2];

    int i = 0, j = 0;

    switch (i) {
    case 0:
        while (i < rows_1) {
            array_1[i] = new int[cols_1];
            i++;
        }
        i = 0;
    }

    switch (i) {
    case 0:
        while (i < rows_2) {
            array_2[i] = new int[cols_2];
            i++;
        }
        i = 0;
    }

    switch (i) {
    case 0:
        while (i < rows_1) {
            j = 0;
            while (j < cols_1) {
                array_1[i][j] = img_1.ptr(i, j)[0];
                j++;
            }
            i++;
        }
        i = 0;
    }

    switch (i) {
    case 0:
        while (i < rows_2) {
            j = 0;
            while (j < cols_2) {
                array_2[i][j] = img_2.ptr(i, j)[0];
                j++;
            }
            i++;
        }
        i = 0;
    }

    int total = 0;

    switch (i) {
    case 0:
        while (i < rows_1) {
            j = 0;
            while (j < cols_1) {
                int add;
                add= array_1[i][j] - array_2[i][j];
                add *= add;
                total += add;
                j++;
            }
            i++;
        }
        i = 0;
    }

    int divide;
        divide = rows_1 * cols_1;

        float X;
        X= float(total / divide);

    int Pixel;
        Pixel= 255 * 255;

        float exp1, exp2,result;
        exp1= X / Pixel;
        exp2 = 1 - exp1;
    result = 100 * exp2;

    cout << "Both The Images Match "<< result <<"% Accurately." << endl;
    return result;
}


int main()
{
    // Define the image file names
    string imageFile_1 = "t5.bmp";
    string imageFile_2 = "MyPhoto.bmp";

    // Load the images
    Mat img_1 = imread(imageFile_1);
    Mat img_2 = imread(imageFile_2);

    // Get the size of the images
    int rows_1 = img_1.rows;
    int cols_1 = img_1.cols;

    int rows_2 = img_2.rows;
    int cols_2 = img_2.cols;

    // Check if the sizes match using switch
    switch ((rows_1 == rows_2) && (cols_1 == cols_2))
    {
        // If the sizes do not match, output an error message
    ////case false:
        cout << "Sizes Do Not Match\nCannot Be Compared" << endl;
        break;

        // If the sizes match, compare the images
    case true:
        compare_Images_accuratly(img_1, img_2);
        break;
    }
}