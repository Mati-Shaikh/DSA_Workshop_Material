/*
i21_1222
M Mati Ur Rehman
CS_A
Assignment_4
*/
#pragma once
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
//Quad Tree Calss and Point structure
// Used to hold details of a point
class Axis {
public:
	//Declaration of two data members in the Axis Class
	int x;
	int y;
	//Declare the prototypes of Axis class
	Axis();
	Axis(int a, int b);
};
//Declare the Axis constructor carrying two variables a and b
Axis::Axis(int a, int b)
{
	x = a;
	y = b;
}
//Declare the Axis constructor 
Axis::Axis()
{
	x = 0;
	y = 0;
}

// The objects that we want stored in the quadtree

// The main quadtree class
class Quad_Tree {
public:
	//Declare two data members of type Axis in the class of Quad_tree
	Axis top_Left;
	Axis bottom_Right;
	//Declare two data members of data type of int
	int data;

	// Children of this tree
	Quad_Tree* top_L_Tree;
	// Children of this tree
	Quad_Tree* top_R_Tree;
	// Children of this tree
	Quad_Tree* bottom_L_Tree;
	// Children of this tree
	Quad_Tree* bottom_R_Tree;
	// Declare the prototyep of QuadTree class
	Quad_Tree();
	// Declare the prototyep of QuadTree class
	Quad_Tree(Axis, Axis);
	//The function which written the file
	void written_into_the_file();
	//{
	//	//Declare the datatypes of string to stire the address f each node
	//	ofstream file;
	//	string addres_node, store_data;
	//	//This node carrying the file path from the desktpk and storee all files in this path
	//	addres_node = "C:/Users/G3/Desktop/OpenCVProject1/OpenCVProject1/QuadTree/";
	//	store_data = addres_node + "Node.txt";
	//	//Boolean head declare as true
	//	bool head = true;
	//	//Now make a quwuw ibject of Queue class and work with this system
	//	Queue<Quad_Tree*> queue;
	//	queue.Enqueue(this);
	//	//Now Declare a string variable and int variable to enqueue the string in the file
	//	string content = "";
	//	int level = 1, count = 1;
	//	//Now using for loop to catter all the data in the file
	//	for (; !queue.isEmpty();)
	//	{
	//		//Now Declare a string variable of current type
	//		Quad_Tree* current = queue.front();
	//		//Carry content of each data in string and get this data in the file as a node
	//		content += to_string(current->data) + "\n";
	//		//Carry content of each data in string and get this data in the file as a node
	//		content += to_string(current->top_Left.x) + "\n";
	//		//Carry content of each data in string and get this data in the file as a node
	//		content += to_string(current->top_Left.y) + "\n";
	//		//Carry content of each data in string and get this data in the file as a node
	//		content += to_string(current->bottom_Right.x) + "\n";
	//		//Carry content of each data in string and get this data in the file as a node
	//		content += to_string(current->bottom_Right.y) + "\n";
	//		//Uisng if/ else to enqueue all the datain the current node and except it
	//		if (current->top_R_Tree)
	//		{
	//			//queue object calling the enqueue function and get all the node data in the child
	//			queue.Enqueue(current->top_R_Tree);
	//			//queue object calling the enqueue function and get all the node data in the child
	//			queue.Enqueue(current->top_L_Tree);
	//			//queue object calling the enqueue function and get all the node data in the child
	//			queue.Enqueue(current->bottom_R_Tree);
	//			//queue object calling the enqueue function and get all the node data in the child
	//			queue.Enqueue(current->bottom_L_Tree);
	//		}
	//		//Uisng switch to get the data and merge it in the file
	//		switch (head)
	//		{
	//			//cases used to true the case and sums up in the data
	//		case true:
	//			file.open(store_data);
	//			file << content << endl;
	//			head = false;
	//			file.close();
	//			break;
	//		case false:
	//			//cases used to true the case and sums up in the data
	//			store_data = addres_node + "n" + to_string(count) + ".txt";
	//			file.open(store_data);
	//			file << content << endl;
	//			file.close();
	//			break;
	//		}
	//		//now gettinh all the data in the loop alternate
	//		content = "";
	//		count++;
	//		queue.Dequeue();
	//	}
	//}//end of function

	void InsertToQuadTree(int** arr);

	//void SetChildData(int** arr, Quad& child, const point& topLeft, const point& botRight);
	//boolean function to det singular data in the fiel
	bool is_Singular(int** arr, Axis top, Axis bottom)
	{
		bool check = true;
		int i = top.x;
		//using while loop to check the bottom point
		while (i < bottom.x && check)
		{
			int j = top.y;
			//using while loop to check the bottom point
			while (j < bottom.y && check)
			{
				//Using switch to check the array in an 
				switch (arr[i][j])
				{
					//cases used to true the case and sums up in the data
				case 0:
					break;
				default:
					check = false;
					break;
				}
				j++;
			}
			i++;
		}

		if (check)
			return true;

		check = true;
		i = top.x;
		//using while loop to check the bottom point
		while (i < bottom.x && check)
		{
			int j = top.y;
			//using while loop to check the bottom point
			while (j < bottom.y && check)
			{
				//Using switch to check the array in an
				switch (arr[i][j])
				{
					//cases used to true the case and sums up in the data
				case 255:
					break;
				default:
					check = false;
					break;
				}
				j++;
			}
			i++;
		}
		//Return thevalue of a function
		return check;
	}



};
Quad_Tree::Quad_Tree()
{
	top_L_Tree = nullptr;
	top_R_Tree = nullptr;
	bottom_L_Tree = nullptr;
	bottom_R_Tree = nullptr;
	top_Left = Axis(0, 0);
	bottom_Right = Axis(0, 0);
}
Quad_Tree::Quad_Tree(Axis topLeft, Axis bottomRight)
{
	top_L_Tree = NULL;
	top_R_Tree = NULL;
	bottom_L_Tree = NULL;
	bottom_R_Tree = NULL;
	top_Left = topLeft;
	bottom_Right = bottomRight;
}

//Class Queue to iterate
template<class T>
class Node
{
public:
	T data;
	Node<T>* next = NULL;
};
template<class T>
class Queue
{
public:
	//Declare th efront and rear pointer get it as NULL
	Node<T>* Front = NULL;
	Node<T>* Rear = NULL;
	//Declare the dfault constructor of Queue class
	Queue()
	{
		Front = NULL;
		Rear = NULL;
	}
	//boolean function check if queue is empty or not
	bool isEmpty()
	{
		if (Front == NULL)
			return true;
		else
			return false;
	}
	//void enqueue function to chech idf queue is not exist enqueue the data
	void Enqueue(T a)
	{
		if (Front != NULL)
		{
			Rear->next = new Node<T>;
			Rear = Rear->next;
			Rear->data = a;
			
		}
		else
		{
			Front = new Node<T>;
			Front->data = a;
			Rear = Front;
		}
	}
	//void enqueue function to chech idf queue is not exist enqueue the data
	void Dequeue()
	{
		if (Front == nullptr)
			return;
		else if (Front->next == nullptr)
		{
			Front = nullptr;
			Rear = nullptr;
		}
		else
		{
			Node<T>* temp = Front;
			Front = Front->next;
			temp = NULL;
			delete temp;
		}
	}
	//a templatized fornt type data in the Queue class
	T front()
	{
		if (Front != NULL)
			return Front->data;
		else
		{
			return 0;
		}
	}

};
//outline Functions of a Queue Class
//List class

class Linked_list {

public:
	//Declare the structe of Node type
	struct Node
	{
	public:
		//Declare the data members od int data type and next pointer
		int data;
		Node* next = NULL;
	};
	//Declare the head of a node
	Node* head;
	//Declare the function prototype of linked_list
	Linked_list();
	void insert_Node(int value);
};
//Declare the function prototype of linked_list
Linked_list::Linked_list()
{
	head = NULL;
}
//Declare the function prototype of linked_list void type
void Linked_list::insert_Node(int value)
{
	//Check the head at front positoion
	if (head != NULL)
	{
		Node* curr = head;
		//using while to check the data in each node
		while (curr->next != NULL)
		{
			curr = curr->next;
		}
		curr->next = new Node;
		curr = curr->next;
		curr->data = value;
	}
	//Using if/else to check the baaneces
	else
	{
		head = new Node;
		head->data = value;
	}
}
//Insertion into the QuadTree
void Quad_Tree::InsertToQuadTree(int** arr)
{
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree 
	Axis a1(top_Left.x, top_Left.y);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis a2((top_Left.x + bottom_Right.x) / 2, (top_Left.y + bottom_Right.y) / 2);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis b1(top_Left.x, (top_Left.y + bottom_Right.y) / 2);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis b2((top_Left.x + bottom_Right.x) / 2, bottom_Right.y);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis c1((top_Left.x + bottom_Right.x) / 2, top_Left.y);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis c2(bottom_Right.x, (top_Left.y + bottom_Right.y) / 2);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis d1((top_Left.x + bottom_Right.x) / 2, (top_Left.y + bottom_Right.y) / 2);
	//Declare the axis from the axis class and take it an object of it and then pass to the quad tree
	Axis d2(bottom_Right.x, bottom_Right.y);
	//Declare the data members of thec clas and form an object
	data = 2;
	top_L_Tree = new Quad_Tree(a1, a2);
	bottom_L_Tree = new Quad_Tree(c1, c2);
	top_R_Tree = new Quad_Tree(b1, b2);
	bottom_R_Tree = new Quad_Tree(d1, d2);
	//using switch to check the situation form the singular data and pass it to the case
	switch (!is_Singular(arr, a1, a2)) {
	case true:
		top_L_Tree->InsertToQuadTree(arr);
		break;
	default:
		top_L_Tree->data = arr[a1.x][a1.y];
		break;
	}
	//using switch to check the situation form the singular data and pass it to the case
	switch (!is_Singular(arr, c1, c2)) {
	case true:
		bottom_L_Tree->InsertToQuadTree(arr);
		break;
	default:
		bottom_L_Tree->data = arr[b1.x][b1.y];
		break;
	}
	//using switch to check the situation form the singular data and pass it to the case
	switch (!is_Singular(arr, b1, b2)) {
	case true:
		top_R_Tree->InsertToQuadTree(arr);
		break;
	default:
		top_R_Tree->data = arr[c1.x][c1.y];
		break;
	}
	//using switch to check the situation form the singular data and pass it to the case
	switch (!is_Singular(arr, d1, d2)) {
	case true:
		bottom_R_Tree->InsertToQuadTree(arr);
		break;
	default:
		bottom_R_Tree->data = arr[d1.x][d1.y];
		break;
	}
}//end of a function
//A void function which converts 2D array into 2D linked List
void convert_To_2d_LL(int** array, int rows, int cols) {
	//Declare an characters just to handle the colors of exception
	char black_pixel = 'f';
	char white_pixel = 'f';
	int i = 0;
	//Declare a Linked_List instance dynamically
	Linked_list* Arr = new Linked_list[rows];
	//Using while to to iterate the i in the loop 
	while (i < rows) {
		int j = 0;
		//Uisng for loop to iterate the j in the loop
		for (; j < cols; j++) {
			//using switch to check wheather its black pixel /while pixel
			switch (black_pixel) {
				//its a case of switch which checks wheather the array manifest the black pixel or white pixel
			case 't':
				//Using if/else to check that if color is balck go for next node else fix the indicator to -1 or -2 in case where it exists
				if (array[i][j] != 0 || array[i][j] == 255) {
					//Using if/else to check that if color is balck go for next node else fix the indicator to -1 or -2 in case where it exists
					if (array[i][j] != 0) {
						black_pixel = 'f';
						white_pixel = 't';
						Arr[i].insert_Node(-1);
						Arr[i].insert_Node(j);
						Arr[i].insert_Node(j - 1);
					}
				}
				//Using if/else to check that if color is balck go for next node else fix the indicator to -1 or -2 in case where it exists
				else if (array[i][j] != 255 || array[i][j] == 0) {
					continue;
				}
				break;
				//its a case of switch which checks wheather the array manifest the black pixel or white pixel
			case 'f':
				//Using if/else to check that if color is balck go for next node else fix the indicator to -1 or -2 in case where it exists
				if (array[i][j] != 0) {
					white_pixel = 't';
					Arr[i].insert_Node(j);
					black_pixel = array[i][j] != 255 ? 't' : 'f';
				}
				//Using if/else to check that if color is balck go for next node else fix the indicator to -1 or -2 in case where it exists
				else if (array[i][j] == 0 || array[i][j] != 255) {
					black_pixel = 't';
					Arr[i].insert_Node(j);
					white_pixel = 'f';
				}
				break;
				//its a case of switch which checks wheather the array manifest the black pixel or white pixel
			case 'w':
				if (array[i][j] != 0) {
					continue;
				}
				else if (array[i][j] == 0) {
					black_pixel = 't';
					white_pixel = 'f';
					Arr[i].insert_Node(-2);
					Arr[i].insert_Node(j);
					Arr[i].insert_Node(j - 1);
				}
				break;
			}
		}
		//using switch to check wheather its black pixel /while pixel
		switch (black_pixel) {
		case 'f':
			Arr[i].insert_Node(-2);
			Arr[i].insert_Node(cols - 1);
			break;
		default:
			Arr[i].insert_Node(-1);
			Arr[i].insert_Node(cols - 1);
			break;
		}
		//Now Again fix the characters into its existing position
		black_pixel = 'f';
		white_pixel = 'f';
		i++;
	}//End of while loop
}//end of 2d linkedlist function
void Quad_Tree::written_into_the_file()
{
	//Declare the datatypes of string to stire the address f each node
	ofstream file;
	string addres_node, store_data;
	//This node carrying the file path from the desktpk and storee all files in this path
	addres_node = "C:/Users/G3/Desktop/OpenCVProject1/OpenCVProject1/QuadTree/";
	store_data = addres_node + "Head.txt";
	//Boolean head declare as true
	bool head = true;
	//Now make a quwuw ibject of Queue class and work with this system
	Queue<Quad_Tree*> queue;
	queue.Enqueue(this);
	//Now Declare a string variable and int variable to enqueue the string in the file
	string content = "";
	int level = 1, count = 1;
	//Now using for loop to catter all the data in the file
	for (; !queue.isEmpty();)
	{
		//Now Declare a string variable of current type
		Quad_Tree* current = queue.front();
		//Carry content of each data in string and get this data in the file as a node
		content += to_string(current->data) + "\n";
		//Carry content of each data in string and get this data in the file as a node
		content += to_string(current->top_Left.x) + "\n";
		//Carry content of each data in string and get this data in the file as a node
		content += to_string(current->top_Left.y) + "\n";
		//Carry content of each data in string and get this data in the file as a node
		content += to_string(current->bottom_Right.x) + "\n";
		//Carry content of each data in string and get this data in the file as a node
		content += to_string(current->bottom_Right.y) + "\n";
		//Uisng if/ else to enqueue all the datain the current node and except it
		if (current->top_R_Tree)
		{
			//queue object calling the enqueue function and get all the node data in the child
			queue.Enqueue(current->top_R_Tree);
			//queue object calling the enqueue function and get all the node data in the child
			queue.Enqueue(current->top_L_Tree);
			//queue object calling the enqueue function and get all the node data in the child
			queue.Enqueue(current->bottom_R_Tree);
			//queue object calling the enqueue function and get all the node data in the child
			queue.Enqueue(current->bottom_L_Tree);
		}
		//Uisng switch to get the data and merge it in the file
		switch (head)
		{
			//cases used to true the case and sums up in the data
		case true:
			file.open(store_data);
			file << content << endl;
			head = false;
			file.close();
			break;
		case false:
			//cases used to true the case and sums up in the data
			store_data = addres_node + "n" + to_string(count) + ".txt";
			file.open(store_data);
			file << content << endl;
			file.close();
			break;
		}
		//now gettinh all the data in the loop alternate
		content = "";
		count++;
		queue.Dequeue();
	}
}//end of function

int** read_from_file(int& object, int& object1)
{
	ifstream reader;
	string address_node, store_data,temp;
	//Declare an 2D array and fill it as NULL
	int** arr = nullptr;
	int counter = 2;
	address_node = "C:/Users/G3/Desktop/OpenCVProject1/OpenCVProject1/QuadTree/";
	store_data = address_node + "Head.txt";
	//Read object to open the file 
	reader.open(store_data);
	//using getline and read every single node from the file
	getline(reader, temp);
	//using getline and read every single node from the file
	getline(reader, temp);
	//using getline and read every single node from the file
	getline(reader, temp);
	//using getline and read every single node from the file
	getline(reader, temp);
	//using getline and read every single node from the file
	object = stoi(temp);
	//using getline and read every single node from the file
	getline(reader, temp);
	//using getline and read every single node from the file
	object1 = stoi(temp);
	//use arr to catter the object
	arr = new int* [object];
	//using for loop to iterate the loop
	for (int i = 0; i < object; i++)
	{
		arr[i] = new int[object1];
	}
	//Declare the data members and work it from the file
	string add = "n";
	add += to_string(counter);
	//Declare the data members and work it from the file
	add += ".txt";
	counter++;
	//Declare the data members and work it from the file
	store_data = address_node + add;
	//close the file
	reader.close();
	//Using for loop to run the case
	for (;true;)
	{
		//Using for loop to run the case
		reader.open(store_data);
		if (!reader)
		{
			reader.close();
			break;
		}
		//using getline and read every single node from the file
		getline(reader, temp);
		//Using swicth //using getline and read every single node from the file
		switch (stoi(temp)) {
		case 2: {
			//Using for loop to run the case
			string add = "n";
			add += to_string(counter);
			//Declare the data members and work it from the file
			add += ".txt";
			counter++;
			//Declare the data members and work it from the file
			store_data = address_node + add;
			reader.close();
			continue;
		}
		default: {
			//Decale data members and convert it in an interger
			int data = stoi(temp);
			//Decale data members and convert it in an interger
			getline(reader, temp);
			//Decale data members and convert it in an interger
			int sx = stoi(temp);
			//Decale data members and convert it in an interger
			getline(reader, temp);
			//Decale data members and convert it in an interger
			int sy = stoi(temp);
			//Decale data members and convert it in an interger
			getline(reader, temp);
			//Decale data members and convert it in an interger
			int ex = stoi(temp);
			//Decale data members and convert it in an interger
			getline(reader, temp);
			int ey = stoi(temp);
			//Using for loop
			for (int i = sx; i < ex; i++)
			{
				for (int j = sy; j < ey; j++)
				{
					arr[i][j] = data;
				}
			}
			//Declare the data members and work it from the file
			string add = "n";
			//Declare the data members and work it from the file
			add += to_string(counter);
			//Declare the data members and work it from the file
			add += ".txt";
			counter++;
			//Declare the data members and work it from the file
			store_data = address_node + add;
			//Declare the data members and work it from the file
			reader.close();
			break;
		}
		}
	}
	cout <<"Total "<< counter <<" Files Readed." << endl;

	return arr;
}

