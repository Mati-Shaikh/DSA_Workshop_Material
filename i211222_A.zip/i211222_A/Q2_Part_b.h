/*
M Mati Ur Rehman
i21-1222
CS-A
Assignment#3
*/
//------------------------------QUESTION-2-PART(B)-------------------
#pragma once
#include <iostream>
#include <string>
//Creating Node class Queues
using namespace std;
class Node {
public:
    int data;
    Node* next;
};

// Define the linked list-based queue
class Queue {
private:
    Node* front;
    Node* rear;
public:
    Queue() {
        front = NULL;
        rear = NULL;
    }

    void enqueue(int x) {
        Node* temp = new Node;
        temp->data = x;
        temp->next = NULL;
        if (front == NULL && rear == NULL) {
            front = rear = temp;
            return;
        }
        rear->next = temp;
        rear = temp;
    }

    int dequeue(void)
    {
        Node* temp;
        int num = -1;
        if (is_empty())
            cout << "The queue is empty.\n";
        else {
            num = front->data;
            temp = front->next;
            delete front;
            front = temp;
            //numItems--;
            //if (!numItems) rear = NULL;
        }
        return num;
    }

    int peek() {
        if (front == NULL) {
            cout << "Queue is empty." << endl;
            return -1;
        }
        return front->data;
    }

    bool is_empty() {
        return front == NULL;
    }
};
//Now Creatin infix_to_postfix_B algorithm function
void infix_to_postfix_B(const string& infix, string& postfix, Queue& operator_stack, Queue& second_queue) 
{
    int i = 0;
    //using loop to check the infix charracter by character
    for (char c;infix[i]<infix.length();)
    {
        //using infix string isdigit to cater the whole thing
        if (isdigit(c)&& infix[i])
        {
            postfix =postfix +c;
        }
        else if (c == '(') {
            operator_stack.enqueue(c);
        }
        else if (c == ')') 
        {
            for (; !operator_stack.is_empty();) 
            {
                for(;operator_stack.peek() != '(';)
                postfix += operator_stack.dequeue();
            }
            if (!operator_stack.is_empty() && operator_stack.peek() == '(') 
            {
                operator_stack.dequeue();
            }
            else {
                // unbalanced parentheses
                cout << "Unbalanced Parenthesis" << endl;
                return;
            }
        }
        else {
            for (; !operator_stack.is_empty() && operator_stack.peek() != '(';)
            {
                for (; (c != '^' && operator_stack.peek() != '^') || (c == '^' && operator_stack.peek() == '^');)
                {
                    second_queue.enqueue(operator_stack.dequeue());
                }
            }
            
            operator_stack.enqueue(c);
        }
    }

    for (; !operator_stack.is_empty();) 
    {
        second_queue.enqueue(operator_stack.dequeue());
    }

    for (; !second_queue.is_empty();) 
    {
        postfix += second_queue.dequeue();
    }
}
