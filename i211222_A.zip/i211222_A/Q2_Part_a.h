/*
M Mati Ur Rehman
i21-1222
CS-A
Assignment#3
*/
//------------------------------QUESTION-2-PART(A)-------------------
#include <iostream>
#include <string>
using namespace std;
//Creating Node class for doubly linked list
class Node {
public:
    string data;
    Node* prev;
    Node* next;
    Node(string data) {
        this->data = data;
        prev = NULL;
        next = NULL;
    }
};
//Creating Doubly Linked List Class
class DoubleLinkedList {
public:
    Node* head;
    Node* tail;
    int size;

    DoubleLinkedList() {
        head = NULL;
        tail = NULL;
        size = 0;
    }

    void push(string data) {
        Node* node = new Node(data);
        if (head == NULL) {
            head = node;
            tail = node;
        }
        else {
            tail->next = node;
            node->prev = tail;
            tail = node;
        }
        size++;
    }

    string pop() {
        if (tail == NULL) {
            return "";
        }
        else if (tail == head) {
            string data = tail->data;
            delete tail;
            tail = NULL;
            head = NULL;
            size--;
            return data;
        }
        else {
            string data = tail->data;
            tail = tail->prev;
            delete tail->next;
            tail->next = NULL;
            size--;
            return data;
        }
    }

    string top() 
    {
        if (tail != NULL) {
            return tail->data;
        }
        else {
            return "";
        }
    }

    bool is_empty() {
        return (size == 0);
    }
};


// Function to check if a character is an operator
bool is_operator(char ch) 
{
    if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%' || ch == '^' || (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Function to get the precedence of an operator
int get_precedence(char ch) 
{
    if (ch == '+' || ch == '-') {
     return 1;
    }
    else if (ch == '/' || ch == '*') {
        return 2;
    }
    else if (ch == '%' || ch == '^') {
        return 3;
    }
    else {
        return 4;
    }
}


// Function to convert an infix expression to a postfix expression
int infix_to_postfix_A(string infix, char* output_stack, DoubleLinkedList& operator_stack) 
{
    int pos = 0; // position in the output stack
    int length = infix.length();
    int i = 0;
    while(i<length)
    {
        if (infix[i] == ' ') { // if used to ignore whitespace in the string
            continue;
        }
        if (is_operator(infix[i])) //this if uses to operate functionalities
        {
            if (infix[i] == '(') 
            {
                operator_stack.push(string(1, infix[i])); // push opening parenthesis to operator stack
            }
            else if (infix[i] == ')') 
            {
                while (!operator_stack.is_empty() && operator_stack.top() != "(") 
                {
                    string temp = operator_stack.pop();
                    output_stack[pos++] = temp[0];
                }
                if (operator_stack.is_empty())
                {
                    continue;
                }
                else if (!operator_stack.is_empty())
                {
                    if (operator_stack.top() == "(")
                    {
                        operator_stack.pop(); // pop opening parenthesis
                    }
                }
                
            }
            else {
                for (;!operator_stack.is_empty() && operator_stack.top() != "(" && get_precedence(infix[i]) <= get_precedence(operator_stack.top()[0]);) 
                {
                    pos = pos + 1;
                    string temp = operator_stack.pop();
                    output_stack[pos] = temp[0];
                }
                operator_stack.push(string(1, infix[i])); // push operator to operator stack
            }
        }
        else 
        {
            pos = pos + 1;
            output_stack[pos] = infix[i]; // push operand to output stack
        }
        i++;
    }
    //This loop checks that stck is not empty so opearte the operands to the stackoperator
    for(;!operator_stack.is_empty();) 
    {
        string temp = operator_stack.pop();
        output_stack[pos++] = temp[0];
    }
    output_stack[pos] = '\0'; // null terminate output stack
    return pos;
}

