/*
M Mati Ur Rehman
i21-1222
CS-A
Assignment#3
*/
//------------------------------QUESTION-2-PART(C)-------------------
#pragma once
#include <iostream>
#include <string>